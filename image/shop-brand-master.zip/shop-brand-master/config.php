<?php

define('DB_HOST', 'localhost');
define('DB_PORT', 3306);
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'shop');
define('DB_CHARSET', 'utf8');
define('DIR_TO_PROD',  '/template/prod');
define('DIR_TO_UPLOAD',  __DIR__ . '/uploads');
define('DIR_TO_UPLOAD_WEB',  '/uploads');
define('APP_VERSION', time());