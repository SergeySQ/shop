<?php

namespace classes\components;

interface ComponentInterface {
    public function init();
}