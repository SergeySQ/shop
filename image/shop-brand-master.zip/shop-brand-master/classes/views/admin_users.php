<div class="row mt-2">
    <div class="col-md-10 offset-md-1">
        <div id="global_alerts"></div>
        <table class="table table-striped">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Username</th>
                <th scope="col">First name</th>
                <th scope="col">Last name</th>
                <th scope="col">Email</th>
                <th scope="col">Permissions</th>
                <th scope="col">Options</th>
            </tr>
            </thead>
            <tbody id="users_container"></tbody>
        </table>
    </div>
</div>