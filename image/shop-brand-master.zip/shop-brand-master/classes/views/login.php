<div class="center login-form">
    <h4 class="login-form__title">LOGIN</h4>
    <label for="username" class="login-form__label">User:</label>
    <input class="login-form__input login-form__input_text" type="text" id="username" name="username">
    <label for="password" class="login-form__label">Password:</label>
    <input class="login-form__input login-form__input_password" type="password" id="password" name="password">
    <button class="login-form__button">Login</button>
    <a href="/register">Register</a>
</div>