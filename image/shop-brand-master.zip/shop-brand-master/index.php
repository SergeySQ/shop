<?php
require_once 'config.php';
require_once 'autoload.php';

use classes\base\App;

App::run();