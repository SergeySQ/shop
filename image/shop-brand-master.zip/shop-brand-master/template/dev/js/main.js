$(document).ready(function (e) {
    var cart = new Cart('header__shop-cart-count', '.products__product');
});